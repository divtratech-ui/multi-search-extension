(() => {
  if (window.top === window.self) return;

  function setNativeValue(el, value) {
    const tag = el.tagName;
    const proto = tag === "TEXTAREA"
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }
  }

  function fillEditable(el, value) {
    el.focus();
    if (el.isContentEditable) {
      el.innerHTML = "";
      document.execCommand("insertText", false, value);
      if (!el.textContent.trim()) {
        el.textContent = value;
      }
      el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, data: value, inputType: "insertText" }));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    setNativeValue(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function findInput() {
    const selectors = [
      'textarea[placeholder*="search" i]',
      'textarea[placeholder*="ask" i]',
      'textarea[aria-label*="search" i]',
      'textarea[aria-label*="ask" i]',
      'input[type="search"]',
      'input[name="q"]',
      'input[name="search"]',
      'input[name="query"]',
      'input[placeholder*="search" i]',
      'input[placeholder*="ask" i]',
      'input[aria-label*="search" i]',
      'input[aria-label*="ask" i]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"][data-placeholder]',
      'div[contenteditable="true"]',
      "textarea",
      'input[type="text"]'
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && !el.disabled && !el.readOnly && el.offsetParent !== null) {
        return el;
      }
    }
    return null;
  }

  function isUsableButton(button) {
    return button && !button.disabled && button.getClientRects().length > 0;
  }

  function clickSubmitButton() {
    const exactSelectors = [
      'button[aria-label="Send message"]',
      'button[aria-label="Submit"]',
      'button[aria-label="Search"]',
      'button[mattooltip="Send message"]',
      'button[data-testid="send-button"]',
      'button[type="submit"]',
      'input[type="submit"]'
    ];

    for (const selector of exactSelectors) {
      const button = document.querySelector(selector);
      if (isUsableButton(button)) {
        button.click();
        return true;
      }
    }

    const broadSelectors = [
      'button[aria-label*="search" i]',
      'button[aria-label*="send" i]',
      'button[aria-label*="submit" i]',
      'button[mattooltip*="send" i]',
      'button[data-testid*="send" i]'
    ];

    for (const selector of broadSelectors) {
      const button = document.querySelector(selector);
      if (isUsableButton(button)) {
        button.click();
        return true;
      }
    }

    return false;
  }

  function pressEnter(el) {
    const enterOptions = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true };
    el.dispatchEvent(new KeyboardEvent("keydown", enterOptions));
    el.dispatchEvent(new KeyboardEvent("keypress", enterOptions));
    el.dispatchEvent(new KeyboardEvent("keyup", enterOptions));
  }

  function submitFrom(el) {
    pressEnter(el);
    if (clickSubmitButton()) return;

    setTimeout(() => {
      if (!el.form) return;
      if (typeof el.form.requestSubmit === "function") {
        el.form.requestSubmit();
      } else {
        el.form.submit();
      }
    }, 150);
  }

  function tryFill(query) {
    const el = findInput();
    if (!el) return false;
    fillEditable(el, query);
    let submitAttempts = 0;
    const submitTimer = setInterval(() => {
      submitAttempts += 1;
      submitFrom(el);
      if (submitAttempts >= 12) {
        clearInterval(submitTimer);
      }
    }, 300);
    return true;
  }

  function getFallbackRequest() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: "GET_SIDE_PANEL_FALLBACK",
        frameUrl: window.location.href
      }, (response) => {
        if (chrome.runtime.lastError || !response || !response.ok) {
          resolve(null);
          return;
        }
        resolve(response.request || null);
      });
    });
  }

  async function run() {
    const request = await getFallbackRequest();
    if (!request) return;

    let attempts = 0;
    const timer = setInterval(() => {
      attempts += 1;
      if (tryFill(request.query) || attempts >= 20) {
        clearInterval(timer);
      }
    }, 500);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run, { once: true });
  } else {
    run();
  }
})();
