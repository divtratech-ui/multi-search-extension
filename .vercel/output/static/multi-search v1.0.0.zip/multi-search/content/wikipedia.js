(function(){
  function fill(query){
    const el=document.querySelector("input#searchInput")||document.querySelector("input[name='search']")||document.querySelector("input[type='search']");
    if(!el) return false;
    el.focus();
    const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value").set; s.call(el,query);
    el.dispatchEvent(new Event("input",{bubbles:true}));
    setTimeout(()=>{ const btn=document.querySelector("button[type='submit']")||document.querySelector("input[type='submit']"); if(btn) btn.click(); else{ const form=el.closest("form"); if(form) form.submit(); } },200);
    return true;
  }
  chrome.runtime.onMessage.addListener((msg,_,res)=>{ if(msg.action!=="fill") return; const ok=fill(msg.query); if(!ok){ let t=0; const iv=setInterval(()=>{ t++; if(fill(msg.query)||t>=6) clearInterval(iv); },400); } res({ok}); });
})();