(function(){
  function fill(query){
    const el=document.querySelector("textarea[placeholder*='Ask']")||document.querySelector("textarea")||document.querySelector("input[type='text']");
    if(!el) return false;
    el.focus();
    const proto=el.tagName==="TEXTAREA"?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;
    const s=Object.getOwnPropertyDescriptor(proto,"value").set; s.call(el,query);
    el.dispatchEvent(new Event("input",{bubbles:true})); el.dispatchEvent(new Event("change",{bubbles:true}));
    setTimeout(()=>{ const btn=document.querySelector("button[aria-label='Submit']")||document.querySelector("button[type='submit']"); if(btn&&!btn.disabled) btn.click(); else el.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,bubbles:true})); },400);
    return true;
  }
  chrome.runtime.onMessage.addListener((msg,_,res)=>{ if(msg.action!=="fill") return; const ok=fill(msg.query); if(!ok){ let t=0; const iv=setInterval(()=>{ t++; if(fill(msg.query)||t>=10) clearInterval(iv); },500); } res({ok}); });
})();