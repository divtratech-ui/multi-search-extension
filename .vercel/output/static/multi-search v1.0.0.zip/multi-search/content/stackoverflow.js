(function(){
  function fill(query){
    const el=document.querySelector("input[name='q']")||document.querySelector("input#search")||document.querySelector(".js-search-field");
    if(!el) return false;
    el.focus();
    const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value").set; s.call(el,query);
    el.dispatchEvent(new Event("input",{bubbles:true}));
    setTimeout(()=>{ const form=el.closest("form"); if(form) form.submit(); else el.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,bubbles:true})); },200);
    return true;
  }
  chrome.runtime.onMessage.addListener((msg,_,res)=>{ if(msg.action!=="fill") return; const ok=fill(msg.query); if(!ok){ let t=0; const iv=setInterval(()=>{ t++; if(fill(msg.query)||t>=6) clearInterval(iv); },400); } res({ok}); });
})();