(function(){
  function fill(query){
    const el=document.querySelector("rich-textarea div[contenteditable='true']")||document.querySelector("div[contenteditable='true'][aria-label]")||document.querySelector("div[contenteditable='true']")||document.querySelector("textarea");
    if(!el) return false;
    el.focus();
    if(el.tagName==="TEXTAREA"){ const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value").set; s.call(el,query); el.dispatchEvent(new Event("input",{bubbles:true})); }
    else{ el.innerHTML=""; document.execCommand("insertText",false,query); if(!el.innerText.trim()){ el.innerText=query; el.dispatchEvent(new InputEvent("input",{bubbles:true})); } }
    setTimeout(()=>{ const btn=document.querySelector("button[aria-label='Send message']")||document.querySelector("button[aria-label='Submit']")||document.querySelector("button[mattooltip='Send message']"); if(btn&&!btn.disabled) btn.click(); else el.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,bubbles:true})); },400);
    return true;
  }
  chrome.runtime.onMessage.addListener((msg,_,res)=>{ if(msg.action!=="fill") return; const ok=fill(msg.query); if(!ok){ let t=0; const iv=setInterval(()=>{ t++; if(fill(msg.query)||t>=12) clearInterval(iv); },500); } res({ok}); });
})();