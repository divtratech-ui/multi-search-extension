(function(){
  function fill(query){
    const el=document.querySelector("#prompt-textarea")||document.querySelector("div[contenteditable='true'][data-placeholder]")||document.querySelector("textarea[placeholder]")||document.querySelector("div[contenteditable='true']");
    if(!el) return false;
    el.focus();
    if(el.tagName==="TEXTAREA"){ const s=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value").set; s.call(el,query); el.dispatchEvent(new Event("input",{bubbles:true})); }
    else{ el.innerText=query; el.dispatchEvent(new InputEvent("input",{bubbles:true,data:query})); }
    setTimeout(()=>{ const btn=document.querySelector("button[data-testid='send-button']")||document.querySelector("button[aria-label='Send message']")||document.querySelector("form button[type='submit']"); if(btn&&!btn.disabled) btn.click(); else el.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",code:"Enter",keyCode:13,bubbles:true})); },300);
    return true;
  }
  chrome.runtime.onMessage.addListener((msg,_,res)=>{ if(msg.action!=="fill") return; const ok=fill(msg.query); if(!ok){ let t=0; const iv=setInterval(()=>{ t++; if(fill(msg.query)||t>=10) clearInterval(iv); },500); } res({ok}); });
})();