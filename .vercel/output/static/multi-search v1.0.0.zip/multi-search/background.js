const DEFAULT_SITES = [
  { id: "google", name: "Google", url: "https://www.google.com/search?q={q}", enabled: true }
];

const FALLBACK_REQUESTS_KEY = "sidePanelFallbackRequests";
const FALLBACK_REQUEST_MAX_AGE_MS = 20000;

async function ensureDefaults() {
  const { sites } = await chrome.storage.sync.get("sites");
  if (!sites || !Array.isArray(sites) || sites.length === 0) {
    await chrome.storage.sync.set({ sites: DEFAULT_SITES });
  }
}

function getOrigin(value) {
  try {
    return new URL(value).origin;
  } catch (e) {
    return "";
  }
}

function getHost(value) {
  try {
    return new URL(value).hostname.replace(/^www\./, "");
  } catch (e) {
    return "";
  }
}

function findFallbackRequest(requests, frameUrl) {
  const origin = getOrigin(frameUrl);
  const host = getHost(frameUrl);
  const now = Date.now();

  return Object.values(requests || {}).find((request) => {
    if (!request || !request.query || !request.targetUrl || !request.createdAt) return false;
    if (now - request.createdAt > FALLBACK_REQUEST_MAX_AGE_MS) return false;
    return getOrigin(request.targetUrl) === origin || getHost(request.targetUrl) === host;
  }) || null;
}

async function openPanel(tab) {
  if (!tab || tab.id == null) return;

  const openPromise = chrome.sidePanel.open({ tabId: tab.id }).catch(async () => {
    if (tab.windowId != null) {
      try { await chrome.sidePanel.open({ windowId: tab.windowId }); } catch (err) {}
    }
  });

  try {
    await chrome.sidePanel.setOptions({
      tabId: tab.id,
      path: "sidepanel.html",
      enabled: true
    });
  } catch (e) {}

  await openPromise;
}

async function setQuery(text) {
  await chrome.storage.session.set({ currentQuery: text, queryAt: Date.now() });
  try {
    await chrome.runtime.sendMessage({ type: "QUERY_UPDATED", text });
  } catch (e) { /* no listeners yet */ }
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  try {
    chrome.contextMenus.create({
      id: "multi-search-selection",
      title: 'Search "%s" in Multi-Search side panel',
      contexts: ["selection"]
    });
  } catch (e) { /* already exists */ }

  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {}
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "SET_SIDE_PANEL_FALLBACK") {
    chrome.storage.session.get(FALLBACK_REQUESTS_KEY).then((result) => {
      const requests = result[FALLBACK_REQUESTS_KEY] || {};
      requests[msg.siteId] = {
        targetUrl: msg.targetUrl,
        query: msg.query,
        createdAt: Date.now()
      };
      return chrome.storage.session.set({ [FALLBACK_REQUESTS_KEY]: requests });
    }).then(() => {
      sendResponse({ ok: true });
    }).catch((err) => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }
  if (msg && msg.action === "GET_SIDE_PANEL_FALLBACK") {
    chrome.storage.session.get(FALLBACK_REQUESTS_KEY).then((result) => {
      const request = findFallbackRequest(result[FALLBACK_REQUESTS_KEY], msg.frameUrl);
      sendResponse({ ok: true, request });
    }).catch((err) => {
      sendResponse({ ok: false, error: err.message });
    });
    return true;
  }
  if (msg && msg.action === "OPEN_FALLBACK_TAB") {
    openFallbackTab(msg.targetUrl, msg.query)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  return false;
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "multi-search-selection") return;
  const text = (info.selectionText || "").trim();
  if (!text) return;

  await openPanel(tab);
  await setQuery(text);
});

chrome.action.onClicked.addListener(async (tab) => {
  await openPanel(tab);
});

async function openFallbackTab(targetUrl, query) {
  if (!targetUrl) throw new Error("Target URL is required.");
  if (!query || !query.trim()) throw new Error("Query is required.");

  const tab = await chrome.tabs.create({ url: targetUrl, active: true });
  await waitForTabComplete(tab.id, 30);
  await new Promise((resolve) => setTimeout(resolve, 1000));
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: performFallbackSearch,
    args: [query.trim()]
  });
}

function waitForTabComplete(tabId, attempts) {
  return new Promise((resolve, reject) => {
    function check(remaining) {
      if (remaining <= 0) {
        reject(new Error("Tab load timeout."));
        return;
      }
      chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (tab.status === "complete") {
          resolve();
          return;
        }
        setTimeout(() => check(remaining - 1), 400);
      });
    }
    check(attempts);
  });
}

function performFallbackSearch(query) {
  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const descriptor = Object.getOwnPropertyDescriptor(proto, "value");
    if (descriptor && descriptor.set) descriptor.set.call(el, value);
    else el.value = value;
  }

  function findInput() {
    const selectors = [
      'textarea[placeholder*="search" i]',
      'textarea[placeholder*="ask" i]',
      'textarea[aria-label*="search" i]',
      'textarea[aria-label*="ask" i]',
      'input[type="search"]',
      'input[name="q"]',
      'input[name="search"]',
      'input[name="query"]',
      'input[placeholder*="search" i]',
      'input[placeholder*="ask" i]',
      'input[aria-label*="search" i]',
      'input[aria-label*="ask" i]',
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"][data-placeholder]',
      'div[contenteditable="true"]',
      "textarea",
      'input[type="text"]'
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && !el.disabled && !el.readOnly && el.getClientRects().length > 0) return el;
    }
    return null;
  }

  function fill(el) {
    el.focus();
    if (el.isContentEditable) {
      el.innerHTML = "";
      document.execCommand("insertText", false, query);
      if (!el.textContent.trim()) el.textContent = query;
      el.dispatchEvent(new InputEvent("beforeinput", { bubbles: true, data: query, inputType: "insertText" }));
      el.dispatchEvent(new InputEvent("input", { bubbles: true, data: query, inputType: "insertText" }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      setNativeValue(el, query);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  function submit(el) {
    const enter = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true };
    el.dispatchEvent(new KeyboardEvent("keydown", enter));
    el.dispatchEvent(new KeyboardEvent("keypress", enter));
    el.dispatchEvent(new KeyboardEvent("keyup", enter));

    const selectors = [
      'button[aria-label="Send message"]',
      'button[aria-label="Submit"]',
      'button[aria-label="Search"]',
      'button[mattooltip="Send message"]',
      'button[data-testid="send-button"]',
      'button[type="submit"]',
      'button[aria-label*="search" i]',
      'button[aria-label*="send" i]',
      'button[aria-label*="submit" i]',
      'input[type="submit"]'
    ];
    for (const selector of selectors) {
      const button = document.querySelector(selector);
      if (button && !button.disabled && button.getClientRects().length > 0) {
        button.click();
        return;
      }
    }
    if (el.form && typeof el.form.requestSubmit === "function") el.form.requestSubmit();
    else if (el.form) el.form.submit();
  }

  let attempts = 0;
  const timer = setInterval(() => {
    attempts += 1;
    const el = findInput();
    if (!el) {
      if (attempts >= 20) clearInterval(timer);
      return;
    }
    fill(el);
    let submitAttempts = 0;
    const submitTimer = setInterval(() => {
      submitAttempts += 1;
      submit(el);
      if (submitAttempts >= 12) clearInterval(submitTimer);
    }, 300);
    clearInterval(timer);
  }, 500);
}

/* ==========================================================================
   ADVANCED AUTOMATED SEARCH QUERY PATTERN DETECTOR ENGINE
   ========================================================================== */
const TEST_SIGNATURE = "TEST_123456789";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.action === "DISCOVER_PATTERN") {
    runDiscoveryEngine(message.url)
      .then((pattern) => sendResponse({ success: true, pattern }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // Keep message channel open for async execution
  }
});

async function runDiscoveryEngine(targetUrl) {
  // 1. Opens the site in an inactive/hidden background tab so it doesn't interrupt the user
  const tab = await chrome.tabs.create({ url: targetUrl, active: false });

  return new Promise((resolve, reject) => {
    let hasResolved = false;

    // Safety timeout to prevent infinite loops if a site blocks scripts or doesn't redirect
    const timeoutGuard = setTimeout(() => {
      if (hasResolved) return;
      cleanup();
      reject(new Error("Pattern discovery timed out."));
    }, 12000);

    // Watcher tracking tab changes to detect if the URL switches to include our signature phrase
    const updateListener = (tabId, changeInfo) => {
      if (tabId !== tab.id) return;
      
      if (changeInfo.url && changeInfo.url.includes(TEST_SIGNATURE)) {
        hasResolved = true;
        const patternUrl = changeInfo.url.replace(TEST_SIGNATURE, "{q}");
        cleanup();
        resolve(patternUrl);
      }
    };

    // Watcher waiting for DOM to settle down before forcefully injecting automation scripts
    const loadListener = async (tabId, changeInfo) => {
      if (tabId !== tab.id || changeInfo.status !== "complete") return;
      
      // Brief delay to let client framework hydrate components safely
      await new Promise((r) => setTimeout(r, 1200));
      if (hasResolved) return;

      try {
        // 2. Injects custom execution context script securely into target tab frame
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: performFormInteractionDiscovery,
          args: [TEST_SIGNATURE]
        });
      } catch (err) {
        // Ignore execution exceptions; continue monitoring in case standard inputs post natively
      }
    };

    chrome.tabs.onUpdated.addListener(updateListener);
    chrome.tabs.onUpdated.addListener(loadListener);

    function cleanup() {
      clearTimeout(timeoutGuard);
      chrome.tabs.onUpdated.removeListener(updateListener);
      chrome.tabs.onUpdated.removeListener(loadListener);
      chrome.tabs.remove(tab.id).catch(() => {});
    }
  });
}

// 3, 4 & 5. Form Crawler running directly inside target page DOM context
function performFormInteractionDiscovery(testString) {
  const selectors = [
    'input[type="search"]',
    'input[name="q"]',
    'input[name="search"]',
    'input[name="query"]',
    'input[placeholder*="search" i]',
    'input[aria-label*="search" i]',
    'input[class*="search" i]'
  ];

  let searchBox = null;
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (element && element.tagName === "INPUT") {
      searchBox = element;
      break;
    }
  }

  if (!searchBox) {
    searchBox = document.querySelector('input[type="text"]');
  }

  if (!searchBox) return;

  searchBox.focus();
  searchBox.value = testString;

  // Emit data changes to satisfy modern frameworks (React/Vue) backing the elements
  searchBox.dispatchEvent(new Event("input", { bubbles: true }));
  searchBox.dispatchEvent(new Event("change", { bubbles: true }));

  // Simulate Keyboard enter tracking events
  const enterOptions = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true };
  searchBox.dispatchEvent(new KeyboardEvent("keydown", enterOptions));
  searchBox.dispatchEvent(new KeyboardEvent("keypress", enterOptions));
  searchBox.dispatchEvent(new KeyboardEvent("keyup", enterOptions));

  // Fallback: forcefully call submit sequence directly on container form element
  if (searchBox.form) {
    searchBox.form.submit();
  }
}
